import UIKit

makePlot()

setXAxis(minimum: -10, maximum: 10)
setYAxis(minimum: -10, maximum: 10)

addPointAt(x: 1, y: 2, color: .black)
addPointAt(x: 3, y: 1, color: .black)
addPointAt(x: 3, y: 4, color: .black)
addPointAt(x: 2, y: 6, color: .black)
addPointAt(x: 4, y: 5, color: .black)
addPointAt(x: 7, y: 5, color: .black)
addPointAt(x: -8, y: 2, color: .black)
addPointAt(x: 10, y: -6, color: .black)
addPointAt(x: -8, y: -9, color: .black)

makeBarChart()

setYAxis(minimum: 0, maximum: 50)

addBar(withLength: 30, color: .blue)
addBar(withLength: 37, color: .green)
addBar(withLength: 23, color: .orange)
addBar(withLength: 10, color: .red)

addBarLabel("Nikola Jokic")
addBarLabel("Kevin Durant")
addBarLabel("Larry Bird")
addBarLabel("Other")

makePieChart()

addWedge(withProportion: 0.37, color: .green)
addWedge(withProportion: 0.30, color: .blue)
addWedge(withProportion: 0.23, color: .orange)
addWedge(withProportion: 0.1, color: .red)

addKeyItem(withLabel: "Kevin Durant", color: .green)
addKeyItem(withLabel: "Nikola Jokic", color: .blue)
addKeyItem(withLabel: "Larry Bird", color: .orange)
addKeyItem(withLabel: "Other", color: .red)
